ECEncoder = comm.BCHEncoder;
ECDecoder = comm.BCHDecoder;
